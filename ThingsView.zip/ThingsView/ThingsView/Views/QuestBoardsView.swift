//
//  QuestBoardsView.swift
//  ThingsView
//
//  Created by Alumno on 10/09/24.
//

import SwiftUI

struct QuestBoardsView: View {
    var body: some View {
        QuestsInfoViews()
            .padding()
    }
}

#Preview {
    QuestBoardsView()
}
