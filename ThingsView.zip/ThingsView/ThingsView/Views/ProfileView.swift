//
//  ProfileView.swift
//  ThingsView
//
//  Created by Alumno on 10/09/24.
//

import SwiftUI

struct ProfileView: View {
    var body: some View {
        Text("This is for Profile")
    }
}

#Preview {
    ProfileView()
}
