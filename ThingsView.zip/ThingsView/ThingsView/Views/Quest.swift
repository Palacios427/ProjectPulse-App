//
//  Quest.swift
//  ThingsView
//
//  Created by Alumno on 10/09/24.
//

import Foundation
struct Quest : Decodable, Identifiable {
    var id : Int
    var name: String
    var title: String
    var description: String
    var team : Int
    var fecha : String
}
