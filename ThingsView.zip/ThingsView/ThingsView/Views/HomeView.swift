//
//  HomeView.swift
//  ThingsView
//
//  Created by Alumno on 10/09/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Text("This is for Home View")
    }
}

#Preview {
    HomeView()
}
