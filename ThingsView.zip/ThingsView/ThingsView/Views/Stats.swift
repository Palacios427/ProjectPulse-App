//
//  Stats.swift
//  ThingsView
//
//  Created by Alumno on 11/09/24.
//

import Foundation
struct Stats : Decodable, Identifiable {
    var name: String
    var proceso: Double
    var maximo : Double
    var id : Int
}
