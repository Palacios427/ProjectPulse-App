//
//  ThingsViewApp.swift
//  ThingsView
//
//  Created by Alumno on 10/09/24.
//

import SwiftUI

@main
struct ThingsViewApp: App {
    var body: some Scene {
        WindowGroup {
            ApplicationView()
        }
    }
}
